package mx.edu.utez.intent

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main2.*
import mx.edu.utez.intent.databinding.ActivityMain2Binding


class MainActivity2 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val binding= ActivityMain2Binding.inflate(layoutInflater)
        setContentView(binding.root)


        Sname.text = intent.getStringExtra("name")
        Saddress.text = intent.getStringExtra("address")
        Scity.text = intent.getStringExtra("city")
        Sstate.text = intent.getStringExtra("state")
        Scp.text = intent.getStringExtra("zipcode")
        Spais.text = intent.getStringExtra("country")

    }
        fun accept(view: View){


            var agree = Intent(this, ThankYou::class.java)
            startActivity(agree)


        }

        fun edit(view: View){


            onBackPressed()


        }


}