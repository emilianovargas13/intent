package mx.edu.utez.intent

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*
import mx.edu.utez.intent.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val binding= ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


    }

        fun mySchedule(view: View){

            var intent = Intent(this@MainActivity, MainActivity2::class.java)

            intent.putExtra("name",name.text.toString())
            intent.putExtra("address",address.text.toString())
            intent.putExtra("city",city.text.toString())
            intent.putExtra("state",state.text.toString())
            intent.putExtra("zipcode",cp.text.toString())
            intent.putExtra("country",pais.text.toString())



            startActivity(intent);



        }


}