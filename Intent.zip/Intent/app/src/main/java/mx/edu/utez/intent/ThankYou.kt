package mx.edu.utez.intent

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ThankYou : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_thank_you)
    }
}